from random import randint, choice

n, m = randint(20, 100000000000000), randint(3, 100)
print(n, m)

for _ in range(m):
    k = randint(2, 805644)
    print(k)
